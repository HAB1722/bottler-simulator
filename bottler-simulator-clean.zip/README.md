# Bottler Simulator 💧

A casual factory management game built with React, TailwindCSS, and Vite.
Supports real-time upgrades, currency detection, and monetization.

## 🧪 Local Dev

```bash
npm install
npm run dev
```

## 🚀 Deploy

Deploy to [https://vercel.com](https://vercel.com) or wrap for App Store.
