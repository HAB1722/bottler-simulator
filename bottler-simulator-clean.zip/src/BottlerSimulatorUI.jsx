export default function BottlerSimulatorUI() {
  return (
    <div className="text-center text-2xl text-blue-600 mt-20">
      Welcome to Bottler Simulator (Clean Version)
    </div>
  );
}